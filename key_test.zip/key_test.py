import json
from urllib import response
import boto3
import pprint
import random

aws_client = boto3.client('ssm')

def lambda_handler(event, context):

    body = {"message": "You did not provide a valid Parameter Name"}
    
    p_name = event['queryStringParameters']['ParameterName']
    p_value = str(random.randint(1000,10000))
    
    msg = {'ParameterName': str(p_name), 'ParameterValue':p_value}
    
    try:
        if event['httpMethod']=='GET' and p_name:
            resp = aws_client.put_parameter( Name = p_name, WithDecryption=True )
            msg = {'ParameterName': p_name, 'ParameterValue': p_value}
    except Exception as e:
        aws_client.put_parameter(
        Name = p_name, Description="A test parameter", Value= p_value, Type="String", 
    Overwrite=True)
        pass
    
    response = {'statusCode': 200, 'body': json.dumps(msg) }
    return response

